# Probabilistic Decomposed Linear Dynamical Systems

"Probabilistic Decomposed Linear Dynamical Systems for Robust Discovery of Latent Neural Dynamics."

Yenho Chen, Noga Mudrik, Adam Charles, Christopher J Rozell

This is the codebase for probabilistic decomposed linear dynamical systems (pdLDS). pdLDS improves robustness against temporal dynamics noise and system nonlinearity by extending the latent dynamics model in dLDS.  



TODO:
- Add citation
- Add Install instructions
- Package up code
- mini tutorial
